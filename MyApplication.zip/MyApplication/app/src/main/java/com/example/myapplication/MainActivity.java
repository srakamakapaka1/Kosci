package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ImageView[] diceImages = new ImageView[5];
    private TextView rollResultText;
    private TextView gameResultText;
    private int gameScore = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        diceImages[0] = findViewById(R.id.dice1);
        diceImages[1] = findViewById(R.id.dice2);
        diceImages[2] = findViewById(R.id.dice3);
        diceImages[3] = findViewById(R.id.dice4);
        diceImages[4] = findViewById(R.id.dice5);

        rollResultText = findViewById(R.id.rollResult);
        gameResultText = findViewById(R.id.gameResult);

        Button rollButton = findViewById(R.id.rollButton);
        rollButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rollDice();
            }
        });

        Button resetButton = findViewById(R.id.resetButton);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });
    }

    private void rollDice() {
        int points = 0;

        ArrayList<Integer> tablica_kostek = new ArrayList<Integer>();

        for (int i = 0; i < diceImages.length; i++) {
            int roll = new Random().nextInt(6) + 1;
            tablica_kostek.add(roll);

            String drawableName = "dice" + roll;
            int resId = getResources().getIdentifier(drawableName, "drawable", getPackageName());
            diceImages[i].setImageResource(resId);
        }

        ArrayList<Integer> tablica_duplikatow = new ArrayList<Integer>();

        for (int j = 0; j < tablica_kostek.size(); j++){
            for (int k = 0; k < tablica_kostek.size(); k++)
            {
                if (tablica_kostek.get(j) == tablica_kostek.get(k) && j != k){
                    boolean czy_zawiera = false;
                    for(int l = 0; l < tablica_duplikatow.size(); l++){
                        if (tablica_duplikatow.get(l) == tablica_kostek.get(j)){
                            czy_zawiera = true;
                            break;
                        }
                    }
                    if(!czy_zawiera){
                        tablica_duplikatow.add(tablica_kostek.get(j));
                    }
                }
            }
        }

        for (int m = 0; m < tablica_duplikatow.size(); m++){
            for (int n = 0; n < tablica_kostek.size(); n++){
                if(tablica_kostek.get(n) == tablica_duplikatow.get(m)){
                    points += tablica_duplikatow.get(m);
                }
            }
        }

        rollResultText.setText("Wynik tego losowania: " + points);

        gameScore += points;
        gameResultText.setText("Wynik gry: " + gameScore);
    }

    private void resetGame() {
        gameScore = 0;
        rollResultText.setText("Wynik tego losowania: 0");
        gameResultText.setText("Wynik gry: 0");

        for (ImageView imageView : diceImages) {
            imageView.setImageResource(R.drawable.question);
        }
    }
}
